<?php
	include "../koneksi.php";
	include "../session.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/bootstrap.min.css" />
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="../css1/sb-admin-2.min.css" rel="stylesheet" />
	<link href="../css1/sb-admin-2.css" rel="stylesheet" />
	<script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/jquery.min.js"></script>
		<script src="../js/bootstrap.min.js"></script>
	</script>
	<link rel="stylesheet" href="../fontawesome/fontawesome/css/all.css" />
    <title>Data Berobat</title>
</head>
<body>
	<div id="wrapper">
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <div class="sidebar-brand d-flex align-items-center justify-content-center">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Administrator</div>
            </div>
            <hr class="sidebar-divider my-0">
            <li class="nav-item active">
                <a class="nav-link" href="data.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span></a>
            </li>
            <hr class="sidebar-divider">
        </ul>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['username'];?></span>
                                <img class="img-profile rounded-circle"
                                    src="../img/irfan.jpg">
                            </a>
                        </li>

                    </ul>

                </nav>
			</div>
			<div class="container shadow p-3">
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb bg-info">
					<li class="breadcrumb-item active text-white" aria-current="page">
						<i class="fa-solid fa-syringe fa-2x"></i> 
						Tabel Obat
					</li>
				  </ol>
				</nav>
				<hr>
				<div class="btn-toolbar mb-2 mb-md-10">
					<a class="btn btn-warning me-3" href="../data.php" role="button"><i class="fa-solid fa-angles-left me-1"></i>Kembali</a>
					<a class="btn btn-primary" href="berobat_tambah.php" role="button"><i class="fa-solid fa-plus me-1"></i>Tambah</a>
				</div>
				<div class="card">
					<div class="table-responsive">
						<table class="table table-striped table-hover">
							<thead>
								<tr>
									<td>No</td>
									<td>Id Berobat</td>
									<td>Nama Pasien</td>
									<td>Nama Dokter</td>
									<td>Tanggal Berobat</td>
									<td>Keluhan Pasien</td>
									<td>Hasil Diagnosa</td>
									<td>Penatalaksanaan</td> 
									<td>Aksi</td>
								</tr>
							</thead>
							<?php
							$no = 1;
							$query = mysqli_query($con, 'SELECT * FROM berobat2');
							while ($data = mysqli_fetch_array($query)) {
							?>
								<tr>
									<td><?php echo $no++ ?></td>
									<td><?php echo $data['id_berobat'] ?></td>
									<td><?php echo $data['nama_pasien'] ?></td>
									<td><?php echo $data['nama_dokter'] ?></td>
									<td><?php echo $data['tgl_berobat'] ?></td>
									<td><?php echo $data['keluhan_pasien'] ?></td>
									<td><?php echo $data['hasil_diagnosa'] ?></td>
									<td><?php echo $data['penatalaksanaan'] ?></td>
									<td>
										<a class="btn btn-success" href="berobat_ubah.php?id=<?= $data['id_berobat'];?>" role="button"><i class="fa-solid fa-pen-to-square"></i></a>
										<a class="btn btn-danger" href="berobat_hapus.php?id=<?= $data['id_berobat'];?>" role="button"><i class="fa-solid fa-trash-can"></i></a>
									</td>
								</tr>
							<?php } ?>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php require "../footer.php";?>
