<?php
	require "koneksi.php";
	include "session.php";
	$querypasien = mysqli_query($con, "SELECT * FROM pasien");
	$jumlahpasien = mysqli_num_rows($querypasien);
	
	$queryobat = mysqli_query($con, "SELECT * FROM obat");
	$jumlahobat = mysqli_num_rows($queryobat);
	
	$querydokter = mysqli_query($con, "SELECT * FROM dokter");
	$jumlahdokter = mysqli_num_rows($querydokter);
	
	$queryberobat = mysqli_query($con, "SELECT * FROM berobat");
	$jumlahberobat = mysqli_num_rows($queryberobat);
	
	$queryresep = mysqli_query($con, "SELECT * FROM resep_obat");
	$jumlahresep = mysqli_num_rows($queryresep);
	
	$queryuser = mysqli_query($con, "SELECT * FROM user");
	$jumlahuser = mysqli_num_rows($queryuser);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/bootstrap.min.css" />
    <script src="js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="fontawesome/fontawesome/css/all.css" />
	<link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css1/sb-admin-2.min.css" rel="stylesheet">
	<link href="css1/sb-admin-2.css" rel="stylesheet">
    <title>Data Klinik</title>
	
	<style>
		
		.kotak {
			border: solid;
		}
		.summary-pasien{
			background-color: #FF0000;
			border-radius: 15px;
		}
		.summary-obat{
			background-color: #0a516b;
			border-radius: 15px;
		}
		.summary-dokter{
			background-color: #008B8B;
			border-radius: 15px;
		}
		.summary-berobat{
			background-color: #8FBC8F;
			border-radius: 15px;
		}
		.summary-resep{
			background-color: #66CDAA;
			border-radius: 15px;
		}
		.summary-user{
			background-color: #DEB887;
			border-radius: 15px;
		}
		.no-decoration{
			text-decoration: none;
		}
		.navbar{
			background-color: #008080;
		}
		.container-data {
			background-color: #FFFFFF;
			padding: 50px 23px;
			margin-bottom: 20px;
		}
	</style>
</head>
<body>
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <div class="sidebar-brand d-flex align-items-center justify-content-center">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Administrator</div>
            </div>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="data.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>
			<li class="nav-item active">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-right-from-bracket"></i>
                    <span>Logout</span></a>
            </li>
            <hr class="sidebar-divider">
        </ul>
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['username'];?></span>
                                <img class="img-profile rounded-circle"
                                    src="img/irfan.jpg">
                            </a>
                        </li>

                    </ul>

                </nav>
			</div>
			<div class="container mx-3">
				<div class="container mt-4">
					<nav aria-label="breadcrumb">
					  <ol class="breadcrumb">
						<li class="breadcrumb-item active" aria-current="page">
							<i class="fa-solid fa-file-medical fa-2x"></i>
							Data Klinik
						</li>
					  </ol>
					</nav>
					<hr>
					<div class="container-data mt-2">
						<div class="row">
							<div class="col-xl-4 col-md-6 mb-4">
								<div class="card border-left-primary shadow h-100 py-2">
									<div class="card-body">
										<div class="row no-gutters align-items-center">
											<div class="col mr-2">
												<div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
													<?php echo $jumlahpasien; ?> Data Pasien
												</div>
												<a href="pasien/pasien.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
											</div>
											<div class="col-auto">
												<i class="fa-solid fa-bed-pulse fa-2x text-gray-300"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="col-xl-4 col-md-6 mb-4">
								<div class="card border-left-success shadow h-100 py-2">
									<div class="card-body">
										<div class="row no-gutters align-items-center">
											<div class="col mr-2">
												<div class="text-xs font-weight-bold text-success text-uppercase mb-1">
													<?php echo $jumlahobat; ?> Data Obat
												</div>
											   <a href="obat/obat.php" class="small-box-footer text-success">More info <i class="fa fa-arrow-circle-right"></i></a>
											</div>
											<div class="col-auto">
												<i class="fa-solid fa-capsules fa-2x text-gray-300"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-xl-4 col-md-6 mb-4">
								<div class="card border-left-info shadow h-100 py-2">
									<div class="card-body">
										<div class="row no-gutters align-items-center">
											<div class="col mr-2">
												<div class="text-xs font-weight-bold text-info text-uppercase mb-1">
													<?php echo $jumlahdokter; ?> Data Dokter
												</div>
											   <a href="dokter/dokter.php" class="small-box-footer text-info">More info <i class="fa fa-arrow-circle-right"></i></a>
											</div>
											<div class="col-auto">
												<i class="fa-solid fa-user-doctor fa-2x text-gray-300"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-xl-4 col-md-6 mb-4">
								<div class="card border-left-warning shadow h-100 py-2">
									<div class="card-body">
										<div class="row no-gutters align-items-center">
											<div class="col mr-2">
												<div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
													<?php echo $jumlahberobat; ?> Data Berobat
												</div>
											   <a href="berobat/berobat.php" class="small-box-footer text-warning">More info <i class="fa fa-arrow-circle-right"></i></a>
											</div>
											<div class="col-auto">
												<i class="fa-solid fa-syringe fa-2x text-gray-300"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-xl-4 col-md-6 mb-4">
								<div class="card border-left-secondary shadow h-100 py-2">
									<div class="card-body">
										<div class="row no-gutters align-items-center">
											<div class="col mr-2">
												<div class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
													<?php echo $jumlahresep; ?> Data Resep
												</div>
											   <a href="resep/resep.php" class="small-box-footer text-secondary">More info <i class="fa fa-arrow-circle-right"></i></a>
											</div>
											<div class="col-auto">
												<i class="fa-solid fa-receipt fa-2x text-gray-300"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
							
							<div class="col-xl-4 col-md-6 mb-4">
								<div class="card border-left-danger shadow h-100 py-2">
									<div class="card-body">
										<div class="row no-gutters align-items-center">
											<div class="col mr-2">
												<div class="text-xs font-weight-bold text-danger text-uppercase mb-1">
													<?php echo $jumlahuser; ?> Data User
												</div>
											   <a href="user/user.php" class="small-box-footer text-danger">More info <i class="fa fa-arrow-circle-right"></i></a>
											</div>
											<div class="col-auto">
												<i class="fa-solid fa-hospital-user fa-2x text-gray-300"></i>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php require "footer.php";?>